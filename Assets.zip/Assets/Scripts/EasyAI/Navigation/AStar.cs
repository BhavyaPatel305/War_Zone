﻿using System.Collections.Generic;
using EasyAI.Navigation.Nodes;
using UnityEngine;
using System;
using System.Linq;

namespace EasyAI.Navigation
{
    /// <summary>
    /// A* pathfinding.
    /// </summary>
    public static class AStar
    {
        /// <summary>
        /// Perform A* pathfinding.
        /// </summary>
        /// <param name="current">The starting position.</param>
        /// <param name="goal">The end goal position.</param>
        /// <param name="connections">All node connections in the scene.</param>
        /// <returns>The path of nodes to take to get from the starting position to the ending position.</returns>
        public static List<Vector3> Perform(Vector3 current, Vector3 goal, List<Connection> connections)
        {

            AStarNode startNode = new AStarNode(current, goal);
            AStarNode endNode = new AStarNode(goal, goal);

            List<AStarNode> nodeList = new List<AStarNode> { startNode };

            while (nodeList.Any(node => node.IsOpen))
            {
                AStarNode currentNode = nodeList.Where(node => node.IsOpen).OrderBy(node => node.CostF).First();

                if (currentNode.Position == goal)
                {
                    List<Vector3> path = new List<Vector3>();
                    AStarNode node = currentNode;
                    while (node != null)
                    {
                        path.Add(node.Position);
                        node = node.Previous;
                    }
                    path.Reverse();
                    return path;
                }

                currentNode.IsOpen = false;

                if (connections == null)
                {
                    throw new ArgumentNullException(nameof(connections));
                }

                // Loop through all connections.
                foreach (Connection connection in connections)
                {
                    // Get those that have the current node as a position.
                    if (connection.A == currentNode.Position || connection.B == currentNode.Position)
                    {
                        // Get the other end of the connection.
                        Vector3 neighborPosition = connection.A == currentNode.Position ? connection.B : connection.A;

                        // Create a new node, we may or may not need to add this but now we can compare costs easily.
                        AStarNode neighborNode = new AStarNode(neighborPosition, goal, currentNode);

                        // See if there is already a node for this position to compare with.
                        AStarNode existingNode = nodeList.FirstOrDefault(node => node.Position == neighborPosition);

                        // If there is no existing node, add the new node to our open list.
                        if (existingNode == null)
                        {
                            nodeList.Add(neighborNode);
                            continue;
                        }

                        // If our existing node has an equal or better cost, no need for our new neighbor node since the existing is better.
                        if (neighborNode.CostF >= existingNode.CostF)
                        {
                            continue;
                        }

                        // Otherwise, the new node is better, so update its previous value and open it again.
                        // This is essentially like adding the new neighbour but without the need to add or remove objects from the list.
                        existingNode.UpdatePrevious(currentNode);
                        existingNode.Open();
                    }
                }
            }

            return null;
        }

    }
}