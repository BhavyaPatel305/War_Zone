﻿using EasyAI;
using UnityEngine;
using Project.Pickups;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Project.States
{
    /// <summary>
    /// The global state which soldiers are always in.
    /// </summary>
    [CreateAssetMenu(menuName = "Project/States/Soldier Mind", fileName = "Soldier Mind")]
    public class SoldierMind : State
    {
        private StringBuilder csvBuilder; // StringBuilder to store CSV data
        private string csvFilePath; // File path of the CSV file
        private float timer; // Timer to track time elapsed

        // Declare a variable to track the last time data was written to .csv
        private float lastWriteTime = 0f;
        // Set the desired interval for writing data to .csv (1 second in this case)
        private float writeInterval = 1f;



        // For writing data to .csv file
        public override void Enter(Agent agent)
        {
            base.Enter(agent);

            // Initialize CSV builder and file path
            csvBuilder = new StringBuilder();
            csvFilePath = Application.dataPath + "/Scripts/Project/SoldierData.csv";

            // Write CSV header
            csvBuilder.AppendLine("TIME,RED,BLUE");

            // Start the timer
            timer = 0f;



        }
        




        public override void Execute(Agent agent)
        {
            // TODO - Project - Create unique behaviours for your soldiers to play capture the flag.

            // FIRST PRIORITY GIVEN TO THE RETURNING THE CAPTURED FLAG TO BASE

            // Get the soldier component
            Soldier soldier = agent.GetComponent<Soldier>();

            // Update the timer
            timer += Time.deltaTime;

            // Check if 1 second has passed since the last write
            if (timer >= 1f && Time.time - lastWriteTime >= writeInterval)
            {
                // Reset the timer
                timer = 0f;

                // Append data to CSV builder
                csvBuilder.AppendLine(string.Format("{0}, {1},{2}",
                    Time.time, SoldierManager.KillsRed, SoldierManager.KillsBlue));

                // Write the CSV data to file
                File.WriteAllText(csvFilePath, csvBuilder.ToString());

                // Update the last write time
                lastWriteTime = Time.time;
            }
            /**
            // To write data to .csv file
            // Update the timer
            timer += Time.deltaTime;

            // Check if 1 second has passed
            if (timer >= 1f)
            {
                
                // Reset the timer
                timer = 0f;


                // Append data to CSV builder
                csvBuilder.AppendLine(string.Format("{0}, {1},{2}",
                    Mathf.FloorToInt(Time.time),SoldierManager.KillsRed, SoldierManager.KillsBlue));

                // Write the CSV data to file
                File.WriteAllText(csvFilePath, csvBuilder.ToString());
            }
            **/

            // Actual program starts

            if (soldier.CarryingFlag)
            {
                // If I have the flag then I will run towards my base
                Vector3 targetPosition1 = soldier.TeamFlagPosition;
                agent.Navigate(targetPosition1);
            }
            else
            {
                // If your ammo is finished then go find ammo first because you are no use if you don't have a gun in game
                // you cannot attack, defend or do anything
                if(soldier.WeaponIndex == 4)
                {
                    // Find a nearest ammo pick up
                    // look for ammo pick up to increase health
                    HealthAmmoPickup ammoPickup = SoldierManager.NearestAmmoPickup(agent, 0);
                    if (ammoPickup != null)
                    {
                        // Move towards the health pickup
                        Vector3 targetPosition2 = ammoPickup.transform.position;
                        agent.Navigate(targetPosition2);
                    }
                }
                else
                {
                    //  Defensive behavior for defenders
                    if (soldier.Role == Soldier.SoliderRole.Defender)
                    {
                        // If you are carrying the flag, quickly return to the base
                        if (soldier.CarryingFlag)
                        {
                            // If I have the flag then I will run towards my base
                            Vector3 targetPosition1 = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition1);
                        }
                        // If my flag is not at the base then I will first go after the flag as a defender
                        if ((!soldier.FlagAtBase) && (!soldier.CarryingFlag))
                        {
                            // Navigate to the location of the flag
                            Vector3 targetPosition = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition);
                        }
                        else
                        {
                            if (!soldier.CarryingFlag)
                            {
                                Vector3 targetPosition = SoldierManager.RandomStrategicPosition(soldier, true);
                                if (!agent.Moving)
                                {
                                    agent.Navigate(targetPosition);
                                }
                                // If health between 40 to 70% of it's value, they try capturing enemy's flag
                                if (soldier.Health < (0.7 * SoldierManager.Health) && soldier.Health >= (0.4 * SoldierManager.Health))
                                {
                                    Vector3 targetPosition1 = soldier.EnemyFlagPosition;
                                    agent.Navigate(targetPosition1);
                                }
                                // If health between 20 to 40% of it's value, then try to kill as much nearest enemy's as possible
                                if (soldier.Health >= (0.2 * SoldierManager.Health) && soldier.Health < (0.4 * SoldierManager.Health))
                                {
                                    // Try to kill as much enemies as possible before dying
                                    Soldier closestEnemy = null;
                                    float closestDistance = Mathf.Infinity;
                                    foreach (var enemy in soldier.SeeEnemies())
                                    {
                                        float distance = Vector3.Distance(soldier.transform.position, enemy.transform.position);
                                        if (distance < closestDistance)
                                        {
                                            closestEnemy = enemy;
                                            closestDistance = distance;
                                        }
                                    }

                                    if (closestEnemy != null)
                                    {
                                        // Set the closest enemy as target
                                        Soldier.TargetData targetData = new Soldier.TargetData();
                                        targetData.Position = closestEnemy.transform.position;
                                        targetData.Enemy = closestEnemy;
                                        targetData.Visible = true;
                                        soldier.SetTarget(targetData);
                                    }
                                }
                                // If health is less than 20% of it's value and dosen't have any flag than just look for health pickup
                                if (soldier.Health < (0.2 * SoldierManager.Health) && !soldier.CarryingFlag)
                                {
                                    // look for health pick up to increase health
                                    HealthAmmoPickup healthPickup = SoldierManager.NearestAmmoPickup(agent, -1);
                                    if (healthPickup != null)
                                    {
                                        // Move towards the health pickup
                                        Vector3 targetPosition2 = healthPickup.transform.position;
                                        agent.Navigate(targetPosition2);
                                    }
                                }
                            }


                        }


                    }

                    if (soldier.Role == Soldier.SoliderRole.Collector)
                    {

                        // If carrying a flag then simply run towards your base
                        if (soldier.CarryingFlag)
                        {
                            // If I have the flag then I will run towards my base
                            Vector3 targetPosition1 = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition1);
                        }
                        else
                        {
                            // No matter what, just keep mkoving towards the flag
                            Vector3 targetPosition = soldier.EnemyFlagPosition;
                            agent.Navigate(targetPosition);
                        }
                    }

                    // Offensive behavior for attackers
                    if (soldier.Role == Soldier.SoliderRole.Attacker)
                    {

                        // If you are carrying the flag, quickly return to the base
                        if (soldier.CarryingFlag)
                        {
                            // If I have the flag then I will run towards my base
                            Vector3 targetPosition1 = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition1);
                        }

                        if (soldier.DetectedEnemies.Count == 0 && (!soldier.CarryingFlag))
                        {
                            // Move to offensive positions 
                            // SoldierManager.RandomStrategicPosition(soldier, false); // Move to offensive points
                            Vector3 targetPosition = soldier.EnemyFlagPosition;
                            agent.Navigate(targetPosition);

                        }
                        else
                        {
                            if (!soldier.CarryingFlag)
                            {
                                // Go for random offensive strategic points
                                Vector3 targetPosition = SoldierManager.RandomStrategicPosition(soldier, false);
                                if (!agent.Moving)
                                {
                                    agent.Navigate(targetPosition);
                                }

                                Soldier closestEnemy = null;
                                float closestDistance = Mathf.Infinity;
                                foreach (var enemy in soldier.SeeEnemies())
                                {
                                    float distance = Vector3.Distance(soldier.transform.position, enemy.transform.position);
                                    if (distance < closestDistance)
                                    {
                                        closestEnemy = enemy;
                                        closestDistance = distance;
                                    }
                                }

                                if (closestEnemy != null)
                                {
                                    // Set the closest enemy as target
                                    Soldier.TargetData targetData = new Soldier.TargetData();
                                    targetData.Position = closestEnemy.transform.position;
                                    targetData.Enemy = closestEnemy;
                                    targetData.Visible = true;
                                    soldier.SetTarget(targetData);
                                }
                            }


                        }
                    }
                }


                
            }

            



        }
        // For writing data to .csv file
        public override void Exit(Agent agent)
        {
            // Reset the timer
            timer = 0f;

            // Clear the CSV builder
            csvBuilder = null;

            base.Exit(agent);
        }
    }
}