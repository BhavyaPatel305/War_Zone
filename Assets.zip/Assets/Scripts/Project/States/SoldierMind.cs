﻿using EasyAI;
using UnityEngine;
using Project.Pickups;

namespace Project.States
{
    /// <summary>
    /// The global state which soldiers are always in.
    /// </summary>
    [CreateAssetMenu(menuName = "Project/States/Soldier Mind", fileName = "Soldier Mind")]
    public class SoldierMind : State
    {
        public override void Execute(Agent agent)
        {
            // TODO - Project - Create unique behaviours for your soldiers to play capture the flag.
            
            // FIRST PRIORITY GIVEN TO THE RETURNING THE CAPTURED FLAG TO BASE
            

            // If no enemies find a defensive position
            Soldier soldier = agent.GetComponent<Soldier>();

            if (soldier.CarryingFlag)
            {
                // If I have the flag then I will run towards my base
                Vector3 targetPosition1 = soldier.TeamFlagPosition;
                agent.Navigate(targetPosition1);
            }
            else
            {
                // If your ammo is finished then go find ammo first because you are no use if you don't have a gun in game
                // you cannot attack, defend or do anything
                if(soldier.WeaponIndex == 4)
                {
                    // Find a nearest health pick up
                    // look for health pick up to increase health
                    HealthAmmoPickup ammoPickup = SoldierManager.NearestAmmoPickup(agent, 0);
                    if (ammoPickup != null)
                    {
                        // Move towards the health pickup
                        Vector3 targetPosition2 = ammoPickup.transform.position;
                        agent.Navigate(targetPosition2);
                    }
                }
                else
                {
                    //  Defensive behavior for defenders
                    if (soldier.Role == Soldier.SoliderRole.Defender)
                    {
                        // If you are carrying the flag, quickly return to the base
                        if (soldier.CarryingFlag)
                        {
                            // If I have the flag then I will run towards my base
                            Vector3 targetPosition1 = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition1);
                        }
                        // If my flag is not at the base then I will first go after the flag as a defender
                        if ((!soldier.FlagAtBase) && (!soldier.CarryingFlag))
                        {
                            // Navigate to the location of the flag
                            Vector3 targetPosition = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition);
                        }
                        else
                        {
                            if (!soldier.CarryingFlag)
                            {
                                Vector3 targetPosition = SoldierManager.RandomStrategicPosition(soldier, true);
                                if (!agent.Moving)
                                {
                                    agent.Navigate(targetPosition);
                                }
                                if (soldier.Health < (0.7 * SoldierManager.Health) && soldier.Health >= (0.4 * SoldierManager.Health))
                                {
                                    Vector3 targetPosition1 = soldier.EnemyFlagPosition;
                                    agent.Navigate(targetPosition1);
                                }
                                if (soldier.Health >= (0.2 * SoldierManager.Health) && soldier.Health < (0.4 * SoldierManager.Health))
                                {
                                    // Try to kill as much enemies as possible before dying
                                    Soldier closestEnemy = null;
                                    float closestDistance = Mathf.Infinity;
                                    foreach (var enemy in soldier.SeeEnemies())
                                    {
                                        float distance = Vector3.Distance(soldier.transform.position, enemy.transform.position);
                                        if (distance < closestDistance)
                                        {
                                            closestEnemy = enemy;
                                            closestDistance = distance;
                                        }
                                    }

                                    if (closestEnemy != null)
                                    {
                                        // Set the closest enemy as target
                                        Soldier.TargetData targetData = new Soldier.TargetData();
                                        targetData.Position = closestEnemy.transform.position;
                                        targetData.Enemy = closestEnemy;
                                        targetData.Visible = true;
                                        soldier.SetTarget(targetData);
                                    }
                                }
                                // If health is less and dosen't have any flag than just look for health pickup
                                if (soldier.Health < (0.2 * SoldierManager.Health) && !soldier.CarryingFlag)
                                {
                                    // look for health pick up to increase health
                                    HealthAmmoPickup healthPickup = SoldierManager.NearestAmmoPickup(agent, -1);
                                    if (healthPickup != null)
                                    {
                                        // Move towards the health pickup
                                        Vector3 targetPosition2 = healthPickup.transform.position;
                                        agent.Navigate(targetPosition2);
                                    }
                                }
                            }


                        }


                    }

                    if (soldier.Role == Soldier.SoliderRole.Collector)
                    {


                        if (soldier.CarryingFlag)
                        {
                            // If I have the flag then I will run towards my base
                            Vector3 targetPosition1 = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition1);
                        }
                        else
                        {
                            // No matter what, just keep mkoving towards the flag
                            Vector3 targetPosition = soldier.EnemyFlagPosition;
                            agent.Navigate(targetPosition);
                        }
                    }

                    // Offensive behavior for attackers
                    if (soldier.Role == Soldier.SoliderRole.Attacker)
                    {

                        // If you are carrying the flag, quickly return to the base
                        if (soldier.CarryingFlag)
                        {
                            // If I have the flag then I will run towards my base
                            Vector3 targetPosition1 = soldier.TeamFlagPosition;
                            agent.Navigate(targetPosition1);
                        }

                        if (soldier.DetectedEnemies.Count == 0 && (!soldier.CarryingFlag))
                        {
                            // Move to offensive positions and start shooting
                            // SoldierManager.RandomStrategicPosition(soldier, false); // Move to offensive points
                            Vector3 targetPosition = soldier.EnemyFlagPosition;
                            agent.Navigate(targetPosition);

                        }
                        else
                        {
                            if (!soldier.CarryingFlag)
                            {
                                // Go for random offensive strategic points
                                Vector3 targetPosition = SoldierManager.RandomStrategicPosition(soldier, false);
                                if (!agent.Moving)
                                {
                                    agent.Navigate(targetPosition);
                                }

                                Soldier closestEnemy = null;
                                float closestDistance = Mathf.Infinity;
                                foreach (var enemy in soldier.SeeEnemies())
                                {
                                    float distance = Vector3.Distance(soldier.transform.position, enemy.transform.position);
                                    if (distance < closestDistance)
                                    {
                                        closestEnemy = enemy;
                                        closestDistance = distance;
                                    }
                                }

                                if (closestEnemy != null)
                                {
                                    // Set the closest enemy as target
                                    Soldier.TargetData targetData = new Soldier.TargetData();
                                    targetData.Position = closestEnemy.transform.position;
                                    targetData.Enemy = closestEnemy;
                                    targetData.Visible = true;
                                    soldier.SetTarget(targetData);
                                }
                            }


                        }
                    }
                }


                
            }

            
           
        }
    }
}