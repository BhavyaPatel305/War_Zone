using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Linq;
using EasyAI;


namespace A1.Actuators
{
    public class CleanerActuator : Actuator
    {
        [Tooltip("How far away from the tile must the agent be to clean it up.")]
        [Min(float.Epsilon)]
        [SerializeField]
        private float collectDistance = 1;

        /// <summary>
        /// Collect a box.
        /// </summary>
        /// <param name="agentAction">The action to perform.</param>
        /// <returns>True if the box was collect, false otherwise.</returns>
        public override bool Act(object agentAction)
        {
            // Cast the action into a transform. If it is anything else this actuator cannot use it so return false.
            // Passing a general transform may become hard in a multi-actuator setup.
            // In such cases making a unique class to wrap said data like transforms for each respective actuator is recommended.
            if (agentAction is not Floor floor)
            {
                return false;
            }
            // Cast the agentAction variable to Floor type
            Floor fl = (Floor)agentAction;

            // Return false if not close enough to pickup the box.
            if (Vector3.Distance(Agent.transform.position, fl.transform.position) > collectDistance)
            {
                Log("Not close enough to clean the tile.");
                return false;
            }

            Log("Tile Cleaned.");
            // Once cleaner cleans a tile then stop there
            Agent.StopMoving();
            // Clean the tile
            fl.Clean();
            return true;
        }
    }

}
