using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Linq;
using EasyAI;


namespace A1.Sensors
{
    public class NearestTileSensor : Sensor
    {
        public override object Sense()
        {
            // Find all boxes in the scene.
            // Constantly finding objects is inefficient, in actual use look for ways to store values.
            //Transform[] boxes = FindObjectsOfType<Transform>().Where(t => t.name.Contains("Box")).ToArray();

            Floor[] floors = CleanerManager.Floors.ToArray();
            List<Floor> dirty_floors = new(); // Dirty floors
            
            
            // Loop to add values to each array above
            foreach (Floor floor in floors)
            {
                
                // Dirty tiles
                if (floor.IsDirty == true)
                {
                    dirty_floors.Add(floor);
                }
            }

            // Return null if there are no dirty tiles.
            if (dirty_floors.Count == 0)
            {
                Log("No Tiles to clean.");
                return null;
            }

            // Return the nearest tile otherwise.
            Log("Getting nearest tile to clean.");
            return dirty_floors.OrderBy(b => Vector3.Distance(Agent.transform.position, b.transform.position)).First();
        }
    }
}

