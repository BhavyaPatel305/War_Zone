using UnityEngine;
using System.Collections;

public class CountDown : MonoBehaviour
{
    // Awake function so that as soons as the program begins, the first thing it does is to start couroutine
    void Awake()
    {
        StartCoroutine(CountdownCoroutine());
    }

    // coroutine to wait for countdown
    private IEnumerator CountdownCoroutine()
    {
        Time.timeScale = 0f; // pause the game

        yield return new WaitForSecondsRealtime(1f);
        Debug.Log("3");
        yield return new WaitForSecondsRealtime(1f);
        Debug.Log("2");
        yield return new WaitForSecondsRealtime(1f);
        Debug.Log("1");

        Time.timeScale = 1f; // resume normal time
        
    }
}
