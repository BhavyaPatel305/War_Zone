
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyAI;
using System.Linq;

using System.Text;
using System.IO;
using System;


namespace A1
{
    public class CleanerPerformance : PerformanceMeasure
    {
        public static int no_of_tiles_cleaned = 0;// Counter to count number of tiles cleaned

        ArrayList data = new ArrayList(); // ArrayList to store performance values every second

        // Used to control that value of variable no_of_tiles_cleaned is added to data array every second
        float timer = 0f;
        int second = 0;

        // To return and display performance value on screen
        public override float CalculatePerformance()
        {

            return no_of_tiles_cleaned;
        }

        // Used to control that value of variable no_of_tiles_cleaned is added to data array every second
        private void Update()
        {
            timer += Time.deltaTime;

            if (timer >= 1f)
            {
                timer = 0f;
                second++;
                data.Add(second + "," + no_of_tiles_cleaned);
            }
        }
        protected override void Start()
        {

            base.Start();

        }

        // This in-built function runs only when you quit the game
        // So what we want is when i quit the application, write all data to .csv file
        private void OnApplicationQuit()
        {
            WriteDataToCSV();
        }

        // Function to write data to .csv file
        public void WriteDataToCSV()
        {
            string path = "C:/WINTER 2023/AI For Games/Assignments/Ass1/Easy-AI-Template/Easy-AI-Template/Assets/Scripts/A1/performance2.csv";

            string dataString = "Seconds,Data\n";

            // Build the string from the ArrayList
            for (int i = 0; i < data.Count; i++)
            {
                dataString += data[i].ToString() + "\n";
            }

            // Create the file if it doesn't exist
            if (!File.Exists(path))
            {
                File.Create(path).Close();
            }

            // Write the data to the file
            File.WriteAllText(path, dataString);
        }

    }

}

