﻿using EasyAI;
using UnityEngine;
using A2.Sensors;
using System.Linq;
using A2.States;
using A2.Pickups;
using A2;

using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System;


namespace A2.States
{
    

    [CreateAssetMenu(menuName = "A2/States/Microbe Mind", fileName = "Microbe Mind")]
    public class MicrobeMind : State
    {
        public override void Execute(Agent agent)
        {
            Microbe mb = agent as Microbe;
            agent.SetState<MicrobeRoamingState>();
            
            // 1's priority: If I am being hunted, forget everything just run away
            if (mb.BeingHunted)
            {
                agent.SetState<MicrobeHuntedState>();
            }
            
            
            // But if I get hungry, then I need to hunt microbes to eat
            if(mb.IsHungry)
            {
                agent.SetState<MicrobeHungryState>();
            }
            


            // If I turn adult and I am not hungry right now then I will search for a mate
            if (mb.IsAdult && (!mb.IsHungry) && (!mb.DidMate))
            {
                agent.SetState<MicrobeMatingState>();
            }
            
            // If I am adult, not hungry, have already mated, not being hunted then I should try to collect eiter offspring or mate pick up, whichever is near to me
            if (mb.IsAdult && !mb.IsHungry && mb.DidMate && !mb.BeingHunted)
            {
                agent.SetState<MicrobeSeekingPickupState>();
            }
            
        }
    }
}


