﻿using EasyAI;
using UnityEngine;
using A2.Sensors;
using System.Linq;

namespace A2.States
{
    /// <summary>
    /// State for microbes that are seeking a mate.
    /// </summary>
    [CreateAssetMenu(menuName = "A2/States/Microbe Mating State", fileName = "Microbe Mating State")]
    public class MicrobeMatingState : State
    {
        Microbe nearestMate = null;
        public override void Enter(Agent agent)
        {
            Microbe mb = agent as Microbe;
            mb._targetMicrobe = null;
        }

        public override void Execute(Agent agent)
        {
            Microbe mb = agent as Microbe;
            // If already mated, do nothing
            if (mb.DidMate) { return; }
            // If it has no target then sense a nearest mate
            if (mb._targetMicrobe == null)
            {
                // Sense a micorbe to mate with
                NearestMateSensor mateSensor = mb.GetComponent<NearestMateSensor>();
                nearestMate = mateSensor.Sense() as Microbe;

                
            }

            // If there is a newarest mate to mate with
            if (nearestMate != null)
            {
                // Then attract it
                mb.AttractMate(nearestMate);
            }

            // Again check if targetMicrobe is still null or not
            if (mb._targetMicrobe == null)
            {
                return;
            }

            // If not null, which means attracting mate was successfull
            // then just go to that microbe to mate
            agent.Move(mb._targetMicrobe.transform);
            // The mate with that microbe
            mb.Mate();
        }

        public override void Exit(Agent agent)
        {
            //agent.SetState<MicrobeRoamingState>();
            
        }
    }
}
