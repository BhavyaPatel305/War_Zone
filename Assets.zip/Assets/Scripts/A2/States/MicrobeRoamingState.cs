﻿using System.Collections.Generic;
using UnityEngine;
using EasyAI;
using EasyAI.Navigation;


namespace A2.States
{
    /// <summary>
    /// Roaming state for the microbe, doesn't have any actions and only logs messages.
    /// </summary>
    [CreateAssetMenu(menuName = "A2/States/Microbe Roaming State", fileName = "Microbe Roaming State")]
    public class MicrobeRoamingState : State
    {
        

        public override void Enter(Agent agent)
        {
            // do nothing
        }

        public override void Execute(Agent agent)
        {
            // Check if I am being hunted or not
            Microbe mb = agent as Microbe;
            bool hunted = mb.BeingHunted;
           
            // Get the current position of the agent
            Vector3 currentPosition = agent.transform.position;


            // Code for random movement
            // If agent is not moving currently 
            if (!agent.Moving)
            {
                agent.Move(MicrobeManager.RandomPosition);
            }
        }

        public override void Exit(Agent agent)
        {
            // do nothing
            
        }

       
    }
}
