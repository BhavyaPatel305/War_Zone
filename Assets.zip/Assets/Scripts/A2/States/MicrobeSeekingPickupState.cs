﻿using EasyAI;
using UnityEngine;
using A2.Pickups;
using A2.Sensors;

namespace A2.States
{
    /// <summary>
    /// State for microbes that are seeking a pickup.
    /// </summary>
    [CreateAssetMenu(menuName = "A2/States/Microbe Seeking Pickup State", fileName = "Microbe Seeking Pickup State")]
    public class MicrobeSeekingPickupState : State
    {
        private MicrobeBasePickup nearestPickup;
        //private bool pickupFound;

        public override void Enter(Agent agent)
        {
            // TODO - Assignment 2 - Complete this state. Have microbes look for pickups.

            
        }
        
        public override void Execute(Agent agent)
        {
            Microbe mb = agent as Microbe;
            // TODO - Assignment 2 - Complete this state. Have microbes look for pickups.
            NearestPickupSensor pickupSensor = agent.GetComponent<NearestPickupSensor>();
            nearestPickup = pickupSensor.Sense() as MicrobeBasePickup;

            // If I am adult, not hungry, have already mated, not being hunted  then I should try to collect eiter offspring or mate pick up, whichever is near to me
            if (mb.IsAdult && !mb.IsHungry && mb.DidMate && !mb.BeingHunted)
            {
                if (nearestPickup.GetType() == typeof(MatePickup) || nearestPickup.GetType() == typeof(OffspringPickup) || nearestPickup.GetType() == typeof(RejuvenatePickup))
                {
                    // Move the microbe towards the pickup
                    agent.Move(nearestPickup.transform.position);

                }
            }
        }
        
        public override void Exit(Agent agent)
        {
            // TODO - Assignment 2 - Complete this state. Have microbes look for pickups.

            nearestPickup = null;
           // pickupFound = false;
        }
    }
}